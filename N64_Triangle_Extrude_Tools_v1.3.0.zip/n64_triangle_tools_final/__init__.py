bl_info = {
    "name": "N64 Triangle Extrude Tools",
    "author": "SirAster",
    "version": (1, 3, 0),
    "blender": (3, 0, 0),
    "location": "Edit Mode > Mesh",
    "description": "Pure-triangle extrude and smart face tools for N64-style modeling",
    "category": "Mesh",
}

import bpy
import bmesh
from mathutils import Vector


def get_ordered_edge_loop(bm, selected_edges):
    if len(selected_edges) < 3:
        return None

    edge_map = {}
    for e in selected_edges:
        v1, v2 = e.verts
        edge_map.setdefault(v1, []).append(e)
        edge_map.setdefault(v2, []).append(e)

    for v, edges in edge_map.items():
        if len(edges) != 2:
            return None

    start_edge = selected_edges[0]
    ordered = [start_edge]
    current_vert = start_edge.verts[1]
    prev_edge = start_edge

    for _ in range(len(selected_edges) - 1):
        candidates = edge_map[current_vert]
        next_edge = candidates[0] if candidates[0] != prev_edge else candidates[1]
        ordered.append(next_edge)
        current_vert = next_edge.other_vert(current_vert)
        prev_edge = next_edge

    return ordered


def split_triangle_by_longest_edge(bm, face):
    if not face.is_valid or len(face.verts) != 3:
        return None

    edges = list(face.edges)
    edges.sort(key=lambda e: e.calc_length(), reverse=True)
    edge = edges[0]

    v1 = edge.verts[0]
    v2 = edge.verts[1]

    opposite = None
    for v in face.verts:
        if v not in (v1, v2):
            opposite = v
            break

    if opposite is None:
        return None

    result = bmesh.utils.edge_split(edge, v1, 0.5)
    mid_vert = None
    for item in result:
        if isinstance(item, bmesh.types.BMVert):
            mid_vert = item
            break

    if mid_vert is None:
        return None

    try:
        bmesh.ops.connect_vert_pair(bm, verts=[mid_vert, opposite])
    except:
        try:
            bm.edges.new((mid_vert, opposite))
        except:
            pass

    return mid_vert


def extrude_edge_to_triangle(bm, selected_edges):
    new_verts = []
    for edge in selected_edges:
        mid = (edge.verts[0].co + edge.verts[1].co) * 0.5
        new_vert = bm.verts.new(mid)
        new_verts.append(new_vert)
        try:
            bm.faces.new((edge.verts[0], edge.verts[1], new_vert))
        except ValueError:
            pass
    return new_verts


class MESH_OT_extrude_edge_to_triangle(bpy.types.Operator):
    bl_idname = "mesh.extrude_edge_to_triangle"
    bl_label = "Extrude Edge to Triangle"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh object")
            return {'CANCELLED'}

        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()

        selected_edges = [e for e in bm.edges if e.select]
        if not selected_edges:
            self.report({'ERROR'}, "No edges selected")
            return {'CANCELLED'}

        new_verts = extrude_edge_to_triangle(bm, selected_edges)

        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False
        for v in new_verts: v.select = True

        bmesh.update_edit_mesh(me)
        bpy.ops.mesh.select_mode(type='VERT')
        self.report({'INFO'}, f"Created {len(new_verts)} triangle(s)")
        return {'FINISHED'}


class MESH_OT_smart_face_tool(bpy.types.Operator):
    """Triangle → split by longest edge | Quad → triangulate"""
    bl_idname = "mesh.smart_face_tool"
    bl_label = "Smart Face Tool"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh object")
            return {'CANCELLED'}

        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        selected_faces = [f for f in bm.faces if f.select]
        if not selected_faces:
            self.report({'WARNING'}, "No faces selected")
            return {'CANCELLED'}

        new_verts = []
        triangulated = 0
        split_count = 0

        for face in list(selected_faces):
            if not face.is_valid:
                continue

            vert_count = len(face.verts)

            if vert_count == 3:
                mid = split_triangle_by_longest_edge(bm, face)
                if mid:
                    new_verts.append(mid)
                    split_count += 1

            elif vert_count == 4:
                try:
                    bmesh.ops.triangulate(bm, faces=[face])
                    triangulated += 1
                except:
                    pass

            bm.faces.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()

        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False

        for v in new_verts:
            if v.is_valid:
                v.select = True

        bmesh.update_edit_mesh(me)
        bpy.ops.mesh.select_mode(type='VERT')

        msg = []
        if split_count:
            msg.append(f"Split {split_count} triangle(s)")
        if triangulated:
            msg.append(f"Triangulated {triangulated} quad(s)")
        self.report({'INFO'}, " | ".join(msg) if msg else "Nothing done")
        return {'FINISHED'}


class MESH_OT_extrude_edge_loop_to_triangles(bpy.types.Operator):
    bl_idname = "mesh.extrude_edge_loop_to_triangles"
    bl_label = "Extrude Edge Loop to Triangles"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh object")
            return {'CANCELLED'}

        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()

        selected_edges = [e for e in bm.edges if e.select]
        if len(selected_edges) < 3:
            self.report({'ERROR'}, "Select a closed loop of at least 3 edges")
            return {'CANCELLED'}

        ordered_edges = get_ordered_edge_loop(bm, selected_edges)
        if ordered_edges is None:
            self.report({'ERROR'}, "Not a clean closed edge loop")
            return {'CANCELLED'}

        n = len(ordered_edges)

        normal = Vector((0, 0, 0))
        for e in ordered_edges:
            normal += (e.verts[0].co + e.verts[1].co)
        if normal.length > 0.0001:
            normal.normalize()
        else:
            normal = Vector((0, 0, 1))

        new_verts = []
        for edge in ordered_edges:
            mid = (edge.verts[0].co + edge.verts[1].co) * 0.5
            nv = bm.verts.new(mid + normal * 0.008)
            new_verts.append(nv)

        bm.verts.ensure_lookup_table()

        for i, edge in enumerate(ordered_edges):
            try:
                bm.faces.new((edge.verts[0], edge.verts[1], new_verts[i]))
            except ValueError:
                pass

        for i in range(n):
            edge_a = ordered_edges[i]
            edge_b = ordered_edges[(i + 1) % n]
            mid_a = new_verts[i]
            mid_b = new_verts[(i + 1) % n]

            shared = None
            for v in edge_a.verts:
                if v in edge_b.verts:
                    shared = v
                    break
            if shared:
                try:
                    bm.faces.new((mid_a, shared, mid_b))
                except ValueError:
                    pass

        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False
        for v in new_verts: v.select = True

        bmesh.update_edit_mesh(me)
        bpy.ops.mesh.select_mode(type='VERT')
        self.report({'INFO'}, f"Created polygonal ring with {n} mid vertices")
        return {'FINISHED'}


addon_keymaps = []

def register():
    bpy.utils.register_class(MESH_OT_extrude_edge_to_triangle)
    bpy.utils.register_class(MESH_OT_smart_face_tool)
    bpy.utils.register_class(MESH_OT_extrude_edge_loop_to_triangles)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Mesh', space_type='EMPTY')

        # Front thumb button → Extrude Edge to Triangle
        kmi1 = km.keymap_items.new(
            "mesh.extrude_edge_to_triangle",
            type='BUTTON5MOUSE', value='PRESS'
        )
        addon_keymaps.append((km, kmi1))

        # Back thumb button → Smart Face Tool
        kmi2 = km.keymap_items.new(
            "mesh.smart_face_tool",
            type='BUTTON4MOUSE', value='PRESS'
        )
        addon_keymaps.append((km, kmi2))

        # Shift + Front thumb button → Loop extrude
        kmi3 = km.keymap_items.new(
            "mesh.extrude_edge_loop_to_triangles",
            type='BUTTON5MOUSE', value='PRESS', shift=True
        )
        addon_keymaps.append((km, kmi3))


def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.utils.unregister_class(MESH_OT_extrude_edge_to_triangle)
    bpy.utils.unregister_class(MESH_OT_smart_face_tool)
    bpy.utils.unregister_class(MESH_OT_extrude_edge_loop_to_triangles)


if __name__ == "__main__":
    register()
